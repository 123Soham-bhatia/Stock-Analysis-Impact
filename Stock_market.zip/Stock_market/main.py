# ==============================
# Stock Market Project (ML + NLP)
# ==============================

import pandas as pd
import re
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from textblob import TextBlob

# -----------------------------
# Load Data
# -----------------------------
try:
    df = pd.read_csv("stock_news_prices.csv")   # ✅ updated file
    print("✅ Dataset loaded successfully!")
except FileNotFoundError:
    print("❌ ERROR: 'stock_news_prices.csv' not found. Please place it in the same folder.")
    exit()

# -----------------------------
# Clean numeric data
# -----------------------------
def clean_numeric(x):
    """Remove $, commas and convert to float."""
    if isinstance(x, str):
        return float(re.sub(r'[^0-9.\-]', '', x))
    return x

for col in ["open", "high", "low", "close"]:
    if col in df.columns:
        df[col] = df[col].apply(clean_numeric)

# Drop rows with missing values
df.dropna(inplace=True)

# -----------------------------
# NLP Part: Sentiment Analysis
# -----------------------------
if "news" in df.columns:
    df["sentiment"] = df["news"].apply(lambda x: TextBlob(str(x)).sentiment.polarity)

    print("\n📰 NLP Sentiment Analysis (first 5 rows):")
    print(df[["news", "sentiment"]].head())
else:
    print("\n⚠️ NLP skipped: No 'news' column found in dataset.")

# -----------------------------
# ML Part: Predict Closing Price
# -----------------------------
if all(col in df.columns for col in ["open", "high", "low", "close"]):
    # 🔹 Use sentiment as an additional feature if available
    features = ["open", "high", "low"]
    if "sentiment" in df.columns:
        features.append("sentiment")

    X = df[features]
    y = df["close"]

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # Train model
    model = LinearRegression()
    model.fit(X_train, y_train)

    # Predict
    predictions = model.predict(X_test)

    print("\n📊 Machine Learning Model Results:")
    print("Mean Absolute Error:", round(mean_absolute_error(y_test, predictions), 2))
    print("R² Score:", round(r2_score(y_test, predictions), 2))

    # Show few predictions
    results_df = pd.DataFrame({
        "Actual": y_test.values,
        "Predicted": predictions
    })
    print("\nSample Predictions (first 5):")
    print(results_df.head())
else:
    print("\n⚠️ ML skipped: Missing required columns [open, high, low, close]")

# -----------------------------
# Final Notes
# -----------------------------
print("\n✅ Project Execution Completed Successfully!")
